--!strict
--[[
init.server.lua
RoBox dashboard server entry point.

Rojo maps this file (init.server.lua) to a Script under ServerScriptService,
so it runs once when the server starts. It creates the settings remote and
the DataStore-backed persistence handler.
]]

require(script.Parent:WaitForChild("SettingsPersistence"))

print("[RoBox Dashboard] server loaded")
