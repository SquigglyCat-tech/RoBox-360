--!strict
--[[
SettingsPersistence.server.lua
Server-validated persistence for RoBox settings.

Every client write is validated against SettingsSchema before it reaches the
DataStore. DataStore failures are handled safely: the server never crashes
and always answers the client, so a missing or failing DataStore degrades
to session-only settings instead of breaking the dashboard.
]]

local DataStoreService = game:GetService("DataStoreService")

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RoBoxStorage = ReplicatedStorage:WaitForChild("RoBox")
local Shared = RoBoxStorage:WaitForChild("Shared")

local SettingsSchema = require(Shared:WaitForChild("SettingsSchema"))

local store = DataStoreService:GetDataStore("RoBoxSettings_v1")

local SettingsPersistence = {}

function SettingsPersistence:_datastoreKey(player: Player, key: string): string
	return "user_" .. tostring(player.UserId) .. "_" .. key
end

function SettingsPersistence:Get(player: Player, key: string): (any?, string?)
	if not SettingsSchema.IsValidKey(key) then
		return nil, "unknown key"
	end

	local data: any? = nil
	local ok, err = pcall(function()
		data = store:GetAsync(self:_datastoreKey(player, key))
	end)
	if not ok then
		warn("RoBox: DataStore read failed for " .. key .. ": " .. tostring(err))
		return nil, "store unavailable"
	end

	if data == nil then
		return SettingsSchema.DEFAULTS[key], nil
	end

	local valid, value = SettingsSchema.Validate(key, data)
	if not valid then
		warn("RoBox: stored value for " .. key .. " failed validation: " .. tostring(value))
		return SettingsSchema.DEFAULTS[key], nil
	end
	return value, nil
end

function SettingsPersistence:Set(player: Player, key: string, value: any): (boolean, string?)
	local valid, cleaned, err = SettingsSchema.Validate(key, value)
	if not valid then
		return false, err
	end

	local ok, serr = pcall(function()
		store:SetAsync(self:_datastoreKey(player, key), cleaned)
	end)
	if not ok then
		warn("RoBox: DataStore write failed for " .. key .. ": " .. tostring(serr))
		return false, "store unavailable"
	end
	return true, nil
end

local function onSettingsInvoke(player: Player, action: string, key: string?, value: any?)
	if action == "Get" then
		local value, err = SettingsPersistence:Get(player, key :: string)
		return { ok = err == nil, value = value, error = err }
	elseif action == "Set" then
		local ok, err = SettingsPersistence:Set(player, key :: string, value)
		return { ok = ok, error = err }
	end
	return { ok = false, error = "unknown action" }
end

local remote = Instance.new("RemoteFunction")
remote.Name = "RoBoxSettings"
remote.Parent = RoBoxStorage
remote.OnServerInvoke = onSettingsInvoke

print("[RoBox Dashboard] settings persistence loaded")

return SettingsPersistence
