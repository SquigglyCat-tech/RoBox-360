--!strict
--[[
Tile.lua
Reusable Metro-style tile component.

A Tile owns a Frame with a border, background, icon glyph, title and subtitle.
It handles its own selection visual -- a single tween per transition, never a
loop -- and reports activation through a callback. The navigation controller
decides WHEN a tile selects or activates; Tile is purely presentational plus
input forwarding (hover and click).
]]

local TweenService = game:GetService("TweenService")

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RoBox = ReplicatedStorage:WaitForChild("RoBox")
local Shared = RoBox:WaitForChild("Shared")

local Theme = require(Shared:WaitForChild("Theme"))

local Tile = {}
Tile.__index = Tile

export type TileSpec = {
	Id: string,
	Title: string,
	Subtitle: string?,
	Glyph: string?,
	Section: string?,
	-- Optional runtime data carried by the tile (e.g. a section definition).
	Data: any?,
	Size: UDim2?,
	Position: UDim2?,
	OnActivated: ((tile: Tile) -> any)?,
	OnHovered: ((tile: Tile) -> any)?,
}

export type Tile = typeof(setmetatable({}, Tile))

function Tile.new(parent: GuiObject, spec: TileSpec): Tile
	local self = setmetatable({}, Tile)
	self.Id = spec.Id
	self.Title = spec.Title
	self.Section = spec.Section
	self.Data = spec.Data
	self._selected = false
	self._hover = false
	self._onActivated = spec.OnActivated
	self._onHovered = spec.OnHovered
	self._activeTween: any = nil

	local frame = Instance.new("Frame")
	frame.Name = "Tile_" .. spec.Id
	frame.Size = spec.Size or Theme.Tile.Size
	frame.Position = spec.Position or UDim2.new(0, 0, 0, 0)
	frame.BackgroundColor3 = Theme.Colors.Panel
	frame.BorderSizePixel = 0
	frame.Parent = parent

	local corner = Instance.new("UICorner")
	corner.CornerRadius = Theme.Tile.CornerRadius
	corner.Parent = frame

	local border = Instance.new("UIStroke")
	border.Name = "SelectionBorder"
	border.Thickness = Theme.Tile.BorderThickness
	border.Color = Theme.Colors.Border
	border.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	border.Parent = frame

	self._frame = frame
	self._border = border

	local icon = Instance.new("TextLabel")
	icon.Name = "Icon"
	icon.Size = UDim2.new(0, Theme.Tile.IconSize, 0, Theme.Tile.IconSize)
	icon.Position = UDim2.new(0, Theme.Spacing.Medium, 0, Theme.Spacing.Medium)
	icon.BackgroundTransparency = 1
	icon.Text = spec.Glyph or ""
	icon.TextColor3 = Theme.Colors.TextMuted
	icon.TextSize = 34
	icon.Font = Theme.Font("Body", Enum.FontWeight.Regular)
	icon.Parent = frame

	local title = Instance.new("TextLabel")
	title.Name = "Title"
	title.Size = UDim2.new(1, -Theme.Tile.IconSize - Theme.Spacing.Medium * 3, 0, 26)
	title.Position = UDim2.new(0, Theme.Tile.IconSize + Theme.Spacing.Medium * 2, 0, Theme.Spacing.Small)
	title.BackgroundTransparency = 1
	title.Text = spec.Title
	title.TextColor3 = Theme.Colors.Text
	title.TextSize = 20
	title.Font = Theme.Font("Body", Enum.FontWeight.SemiBold)
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.TextWrapped = true
	title.Parent = frame

	local subtitle = Instance.new("TextLabel")
	subtitle.Name = "Subtitle"
	subtitle.Size = UDim2.new(1, -Theme.Tile.IconSize - Theme.Spacing.Medium * 3, 0, 20)
	subtitle.Position = UDim2.new(0, Theme.Tile.IconSize + Theme.Spacing.Medium * 2, 0, Theme.Spacing.Small + 28)
	subtitle.BackgroundTransparency = 1
	subtitle.Text = spec.Subtitle or ""
	subtitle.TextColor3 = Theme.Colors.TextMuted
	subtitle.TextSize = 14
	subtitle.Font = Theme.Font("Body", Enum.FontWeight.Regular)
	subtitle.TextXAlignment = Enum.TextXAlignment.Left
	subtitle.TextWrapped = true
	subtitle.Parent = frame

	local hit = Instance.new("TextButton")
	hit.Name = "HitBox"
	hit.Size = UDim2.new(1, 0, 1, 0)
	hit.BackgroundTransparency = 1
	hit.Text = ""
	hit.AutoButtonColor = false
	hit.Parent = frame

	hit.MouseButton1Click:Connect(function()
		self:Activate()
	end)

	hit.MouseEnter:Connect(function()
		if not self._selected then
			self._hover = true
			border.Color = Theme.Colors.BorderSelected
			border.Thickness = Theme.Tile.BorderThickness + 1
		end
		if self._onHovered then
			self._onHovered(self)
		end
	end)

	hit.MouseLeave:Connect(function()
		if not self._selected then
			self._hover = false
			border.Color = Theme.Colors.Border
			border.Thickness = Theme.Tile.BorderThickness
		end
	end)

	return self
end

function Tile:_tween(propertyTable: { [string]: any }, duration: number?, easingStyle: Enum.EasingStyle?, easingDirection: Enum.EasingDirection?)
	if self._activeTween then
		self._activeTween:Cancel()
	end
	local info = TweenInfo.new(
		duration or 0.2,
		easingStyle or Enum.EasingStyle.Quad,
		easingDirection or Enum.EasingDirection.Out
	)
	local tween = TweenService:Create(self._frame, info, propertyTable)
	tween:Play()
	self._activeTween = tween
	tween.Completed:Connect(function()
		if self._activeTween == tween then
			self._activeTween = nil
		end
	end)
end

function Tile:Select()
	if self._selected then
		return
	end
	self._selected = true
	self._hover = false
	local border = self._border
	border.Color = Theme.Colors.BorderSelected
	border.Thickness = Theme.Tile.SelectedBorderThickness
	self:_tween({
		BackgroundColor3 = Theme.Colors.PanelElevated,
	})
end

function Tile:Deselect()
	if not self._selected then
		return
	end
	self._selected = false
	local border = self._border
	if self._hover then
		border.Color = Theme.Colors.BorderSelected
		border.Thickness = Theme.Tile.BorderThickness + 1
	else
		border.Color = Theme.Colors.Border
		border.Thickness = Theme.Tile.BorderThickness
	end
	self:_tween({
		BackgroundColor3 = Theme.Colors.Panel,
	})
end

function Tile:IsSelected(): boolean
	return self._selected
end

function Tile:Activate()
	if self._onActivated then
		self._onActivated(self)
	end
end

function Tile:SetSubtitle(text: string)
	local subtitle = self._frame:FindFirstChild("Subtitle")
	if subtitle:IsA("TextLabel") then
		subtitle.Text = text
	end
end

function Tile:Destroy()
	self._frame:Destroy()
end

return Tile
