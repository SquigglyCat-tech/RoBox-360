--!strict
--[[
SettingsClient.lua
Client settings cache with server-validated persistence.

Reads fall back to local defaults when the remote is missing or the server
fails; writes are sent to the server, validated there against
SettingsSchema, and only applied optimistically to the local cache when the
server confirms. No polling: exactly one RemoteFunction call per request.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RoBox = ReplicatedStorage:WaitForChild("RoBox")
local Shared = RoBox:WaitForChild("Shared")

local SettingsSchema = require(Shared:WaitForChild("SettingsSchema"))

local SettingsClient = {}
SettingsClient.__index = SettingsClient

export type SettingsClient = typeof(setmetatable({}, SettingsClient))

function SettingsClient.new(): SettingsClient
	local self = setmetatable({}, SettingsClient)
	self._cache = SettingsSchema.CloneDefaults()
	self._remote = nil

	local ok, remote = pcall(function()
		return ReplicatedStorage:WaitForChild("RoBox"):WaitForChild("RoBoxSettings", 10)
	end)
	if ok and remote ~= nil then
		self._remote = remote :: RemoteFunction
	end
	return self
end

function SettingsClient:Get(key: string): any?
	if not SettingsSchema.IsValidKey(key) then
		warn("RoBox: unknown setting key " .. tostring(key))
		return nil
	end

	if self._remote then
		local ok, result = pcall(function()
			return self._remote:InvokeServer("Get", key)
		end)
		if ok and result ~= nil then
			local valid, value = SettingsSchema.Validate(key, result)
			if valid then
				self._cache[key] = value
				return value
			end
		end
		warn("RoBox: failed to read setting " .. key .. "; using local value")
	end

	return self._cache[key]
end

function SettingsClient:Set(key: string, value: any): boolean
	local valid, cleaned, err = SettingsSchema.Validate(key, value)
	if not valid then
		warn("RoBox: invalid setting " .. tostring(key) .. ": " .. tostring(err))
		return false
	end

	self._cache[key] = cleaned

	if self._remote then
		local ok, response = pcall(function()
			return self._remote:InvokeServer("Set", key, cleaned)
		end)
		if ok and type(response) == "table" then
			return response.ok == true
		end
		warn("RoBox: failed to persist setting " .. key .. "; kept locally")
		return true
	end

	-- No server available: local-only setting still counts as applied.
	return true
end

function SettingsClient:GetAll(): { [string]: any }
	local copy = {}
	for k, v in pairs(self._cache) do
		copy[k] = v
	end
	return copy
end

return SettingsClient
