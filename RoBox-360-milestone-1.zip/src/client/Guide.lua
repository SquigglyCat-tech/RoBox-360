--!strict
--[[
Guide.lua
RoBox Guide overlay.

Opens over the current screen and closes without disturbing the dashboard:
Navigation remembers the previous selection and restores it on close. While
open, directional input moves the Guide's own focus instead of the dashboard
selection.
]]

local TweenService = game:GetService("TweenService")

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RoBox = ReplicatedStorage:WaitForChild("RoBox")
local Shared = RoBox:WaitForChild("Shared")

local Theme = require(Shared:WaitForChild("Theme"))

local Guide = {}
Guide.__index = Guide

export type GuideItem = {
	Text: string,
	OnActivated: () -> any,
	_button: TextButton?,
	_bar: Frame?,
}

export type Guide = typeof(setmetatable({}, Guide))

function Guide.new(screenGui: ScreenGui): Guide
	local self = setmetatable({}, Guide)
	self._open = false
	self._items: { GuideItem } = {}
	self._selectedIndex = 1

	local dimmer = Instance.new("Frame")
	dimmer.Name = "GuideDimmer"
	dimmer.Size = UDim2.new(1, 0, 1, 0)
	dimmer.BackgroundColor3 = Color3.new(0, 0, 0)
	dimmer.BackgroundTransparency = 0.5
	dimmer.BorderSizePixel = 0
	dimmer.Visible = false
	dimmer.ZIndex = 20
	dimmer.Parent = screenGui

	local panel = Instance.new("Frame")
	panel.Name = "GuidePanel"
	panel.Size = UDim2.new(0, 560, 0, 380)
	panel.Position = UDim2.new(0.5, -280, 0.5, -240)
	panel.BackgroundColor3 = Theme.Colors.PanelElevated
	panel.BorderSizePixel = 0
	panel.Visible = false
	panel.ZIndex = 21
	panel.Parent = screenGui

	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 16)
	corner.Parent = panel

	local title = Instance.new("TextLabel")
	title.Name = "Title"
	title.Size = UDim2.new(1, -32, 0, 40)
	title.Position = UDim2.new(0, 24, 0, 18)
	title.BackgroundTransparency = 1
	title.Text = "RoBox Guide"
	title.TextColor3 = Theme.Colors.Text
	title.TextSize = 26
	title.Font = Theme.Font("Display", Enum.FontWeight.SemiBold)
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.ZIndex = 22
	title.Parent = panel

	local list = Instance.new("ScrollingFrame")
	list.Name = "List"
	list.Size = UDim2.new(1, -24, 1, -96)
	list.Position = UDim2.new(0, 12, 0, 70)
	list.BackgroundTransparency = 1
	list.BorderSizePixel = 0
	list.ScrollBarThickness = 6
	list.AutomaticCanvasSize = Enum.AutomaticSize.Y
	list.ZIndex = 22
	list.Parent = panel

	local layout = Instance.new("UIListLayout")
	layout.Name = "Layout"
	layout.Padding = UDim.new(0, 8)
	layout.SortOrder = Enum.SortOrder.LayoutOrder
	layout.Parent = list

	local hint = Instance.new("TextLabel")
	hint.Name = "Hint"
	hint.Size = UDim2.new(1, -24, 0, 22)
	hint.Position = UDim2.new(0, 12, 1, -26)
	hint.AnchorPoint = Vector2.new(0, 1)
	hint.BackgroundTransparency = 1
	hint.Text = "DPad / arrows move  ·  A / Enter select  ·  B / Esc back"
	hint.TextColor3 = Theme.Colors.TextMuted
	hint.TextSize = 14
	hint.Font = Theme.Font("Body", Enum.FontWeight.Regular)
	hint.TextXAlignment = Enum.TextXAlignment.Left
	hint.ZIndex = 22
	hint.Parent = panel

	self._dimmer = dimmer
	self._panel = panel
	self._list = list
	self._layout = layout

	return self
end

function Guide:Open(items: { GuideItem })
	self._items = items or {}
	if #self._items == 0 then
		return
	end
	self._selectedIndex = math.clamp(self._selectedIndex, 1, #self._items)
	self:_rebuild()

	self._dimmer.Visible = true
	self._panel.Visible = true
	self._panel.Position = UDim2.new(0.5, -280, 0.5, -260)
	self._open = true

	TweenService:Create(self._dimmer, Theme.Animation.Fade, { BackgroundTransparency = 0.35 }):Play()
	TweenService:Create(
		self._panel,
		Theme.Animation.Guide,
		{ Position = UDim2.new(0.5, -280, 0.5, -200) }
	):Play()
	self:_updateSelectionVisuals()
end

function Guide:Close()
	if not self._open then
		return
	end
	self._open = false
	TweenService:Create(self._dimmer, Theme.Animation.Fade, { BackgroundTransparency = 0.5 }):Play()
	TweenService:Create(
		self._panel,
		Theme.Animation.Guide,
		{ Position = UDim2.new(0.5, -280, 0.5, -260) }
	):Play()
	task.delay(0.22, function()
		if not self._open then
			self._dimmer.Visible = false
			self._panel.Visible = false
		end
	end)
end

function Guide:IsOpen(): boolean
	return self._open
end

function Guide:SelectNext()
	if #self._items == 0 then
		return
	end
	self._selectedIndex = math.clamp(self._selectedIndex + 1, 1, #self._items)
	self:_updateSelectionVisuals()
end

function Guide:SelectPrevious()
	if #self._items == 0 then
		return
	end
	self._selectedIndex = math.clamp(self._selectedIndex - 1, 1, #self._items)
	self:_updateSelectionVisuals()
end

function Guide:ActivateSelected()
	local item = self._items[self._selectedIndex]
	if item and item.OnActivated then
		item.OnActivated()
	end
end

function Guide:_rebuild()
	for _, child in ipairs(self._list:GetChildren()) do
		if child ~= self._layout and child:IsA("GuiObject") then
			child:Destroy()
		end
	end

	for i, item in ipairs(self._items) do
		local button = Instance.new("TextButton")
		button.Name = "Item_" .. i
		button.Size = UDim2.new(1, 0, 0, 44)
		button.BackgroundTransparency = 1
		button.Text = item.Text
		button.TextColor3 = Theme.Colors.TextMuted
		button.TextSize = 20
		button.Font = Theme.Font("Body", Enum.FontWeight.Regular)
		button.TextXAlignment = Enum.TextXAlignment.Left
		button.LayoutOrder = i
		button.ZIndex = 22
		button.Parent = self._list

		local bar = Instance.new("Frame")
		bar.Name = "SelectBar"
		bar.Size = UDim2.new(0, 4, 1, 0)
		bar.Position = UDim2.new(0, 0, 0, 0)
		bar.BackgroundColor3 = Theme.Colors.Accent
		bar.BorderSizePixel = 0
		bar.Visible = false
		bar.ZIndex = 22
		bar.Parent = button

		button.MouseButton1Click:Connect(function()
			self._selectedIndex = i
			self:_updateSelectionVisuals()
			item.OnActivated()
		end)

		item._button = button
		item._bar = bar
	end

	self:_updateSelectionVisuals()
end

function Guide:_updateSelectionVisuals()
	for i, item in ipairs(self._items) do
		local selected = i == self._selectedIndex
		local button = item._button
		local bar = item._bar
		if button then
			button.TextColor3 = selected and Theme.Colors.Text or Theme.Colors.TextMuted
		end
		if bar then
			bar.Visible = selected
		end
	end
end

return Guide
