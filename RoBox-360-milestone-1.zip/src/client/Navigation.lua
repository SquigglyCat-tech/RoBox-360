--!strict
--[[
Navigation.lua
Central dashboard state and navigation controller.

Owns: the ordered section list, the per-section selected tile index, the
current section, and the Guide open/closed state -- including the previous
selection, so the Guide can close without losing where the user was.

Knows nothing about UI. It communicates through BindableEvents:
  SelectionChanged(sectionId, index)
  TileActivated(sectionId, index, tile)
  SectionChanged(sectionId)
  GuideToggled(isOpen)
]]

local Constants = script.Parent.Parent:WaitForChild("Shared"):WaitForChild("Constants")
Constants = require(Constants)

local Navigation = {}
Navigation.__index = Navigation

export type Navigation = typeof(setmetatable({}, Navigation))

local function bindable(name: string)
	local event = Instance.new("BindableEvent")
	event.Name = name
	return event
end

function Navigation.new(): Navigation
	local self = setmetatable({}, Navigation)

	self.Sections: { string } = {} -- ordered section ids
	self._tileLists: { [string]: { any } } = {} -- sectionId -> tiles
	self._selectedIndex: { [string]: number } = {}
	self.CurrentSection: string? = nil
	self.GuideOpen = false
	self._previousSelection: { Section: string, Index: number }? = nil
	self._columns = 3

	self.SelectionChanged = bindable("SelectionChanged")
	self.TileActivated = bindable("TileActivated")
	self.SectionChanged = bindable("SectionChanged")
	self.GuideToggled = bindable("GuideToggled")

	return self
end

function Navigation:RegisterSection(sectionId: string, tileCount: number)
	assert(sectionId ~= nil, "Navigation: sectionId is required")
	assert(tileCount ~= nil and tileCount >= 0, "Navigation: bad tileCount")
	if self._tileLists[sectionId] ~= nil then
		return
	end
	self._tileLists[sectionId] = {}
	self._selectedIndex[sectionId] = 1
	table.insert(self.Sections, sectionId)
	if self.CurrentSection == nil then
		self.CurrentSection = sectionId
	end
end

function Navigation:SetTiles(sectionId: string, tiles: { any })
	assert(self._tileLists[sectionId] ~= nil, "Navigation: unknown section " .. tostring(sectionId))
	self._tileLists[sectionId] = tiles or {}
	local count = #self._tileLists[sectionId]
	local current = self._selectedIndex[sectionId] or 1
	if count == 0 then
		self._selectedIndex[sectionId] = 0
	elseif current > count then
		self._selectedIndex[sectionId] = count
	end
end

function Navigation:GetSelectedIndex(sectionId: string?): number
	sectionId = sectionId or self.CurrentSection
	return self._selectedIndex[sectionId] or 1
end

function Navigation:GetSelectedTile(sectionId: string?): any?
	sectionId = sectionId or self.CurrentSection
	if not sectionId then
		return nil
	end
	local index = self._selectedIndex[sectionId]
	local tiles = self._tileLists[sectionId] or {}
	if index < 1 or index > #tiles then
		return nil
	end
	return tiles[index]
end

function Navigation:SelectSection(sectionId: string)
	assert(self._tileLists[sectionId] ~= nil, "Navigation: unknown section " .. tostring(sectionId))
	if self.CurrentSection == sectionId then
		return
	end
	self.CurrentSection = sectionId
	local index = self._selectedIndex[sectionId] or 1
	self.SectionChanged:Fire(sectionId)
	self.SelectionChanged:Fire(sectionId, index)
end

function Navigation:SelectIndex(sectionId: string?, index: number)
	sectionId = sectionId or self.CurrentSection
	if not sectionId then
		return
	end
	local tiles = self._tileLists[sectionId] or {}
	if #tiles == 0 then
		return
	end
	index = math.clamp(index, 1, #tiles)
	if self._selectedIndex[sectionId] == index then
		return
	end
	self._selectedIndex[sectionId] = index
	self.SelectionChanged:Fire(sectionId, index)
end

function Navigation:_rowColumn(index: number): (number, number)
	local columns = math.max(1, self._columns)
	local zero = index - 1
	return math.floor(zero / columns), (zero % columns) + 1
end

-- Directional navigation inside the current section's tile grid. The grid
-- wraps responsively; Left/Right never cross row boundaries, Up/Down clamp
-- to the tile count.
function Navigation:Move(direction: string)
	local sectionId = self.CurrentSection
	if not sectionId or self.GuideOpen then
		return
	end
	local tiles = self._tileLists[sectionId] or {}
	if #tiles == 0 then
		return
	end
	local index = self._selectedIndex[sectionId] or 1
	local columns = math.max(1, self._columns)
	local count = #tiles
	local row, col = self:_rowColumn(index)
	local newIndex = index

	if direction == "Right" then
		if col < columns then
			newIndex = index + 1
		end
	elseif direction == "Left" then
		if col > 1 then
			newIndex = index - 1
		end
	elseif direction == "Down" then
		newIndex = index + columns
	elseif direction == "Up" then
		newIndex = index - columns
	end

	newIndex = math.clamp(newIndex, 1, count)
	self:SelectIndex(sectionId, newIndex)
end

function Navigation:SetColumns(columns: number)
	self._columns = math.max(1, columns or 1)
end

function Navigation:ActivateSelected()
	local sectionId = self.CurrentSection
	if not sectionId then
		return
	end
	local index = self._selectedIndex[sectionId]
	local tiles = self._tileLists[sectionId] or {}
	if index < 1 or index > #tiles then
		return
	end
	local tile = tiles[index]
	self.TileActivated:Fire(sectionId, index, tile)
end

-- Guide state management. The previous selection is remembered so CloseGuide
-- can restore focus without losing where the user was.
function Navigation:OpenGuide()
	if self.GuideOpen then
		return
	end
	self._previousSelection = {
		Section = self.CurrentSection,
		Index = self._selectedIndex[self.CurrentSection] or 1,
	}
	self.GuideOpen = true
	self.GuideToggled:Fire(true)
end

function Navigation:CloseGuide(restoreSelection: boolean?)
	if not self.GuideOpen then
		return
	end
	self.GuideOpen = false
	if restoreSelection and self._previousSelection then
		local prev = self._previousSelection
		local tiles = self._tileLists[prev.Section] or {}
		local index = math.clamp(prev.Index, 1, math.max(1, #tiles))
		self.CurrentSection = prev.Section
		self._selectedIndex[prev.Section] = index
		self.SectionChanged:Fire(prev.Section)
		self.SelectionChanged:Fire(prev.Section, index)
	end
	self._previousSelection = nil
	self.GuideToggled:Fire(false)
end

function Navigation:ToggleGuide()
	if self.GuideOpen then
		self:CloseGuide(true)
	else
		self:OpenGuide()
	end
end

return Navigation
