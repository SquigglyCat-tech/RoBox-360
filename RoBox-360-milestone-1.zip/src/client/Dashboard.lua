--!strict
--[[
Dashboard.lua
RoBox dashboard shell: ScreenGui, screen stack, home screen, guide overlay
and the wiring between Navigation, Input and screens.

Screens are pushed onto a stack. The Guide is an overlay above everything;
Navigation remembers the selection that was active when it opened and
restores it on close.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RoBoxStorage = ReplicatedStorage:WaitForChild("RoBox")
local Shared = RoBoxStorage:WaitForChild("Shared")

local Theme = require(Shared:WaitForChild("Theme"))
local Constants = require(Shared:WaitForChild("Constants"))
local SimulatedData = require(Shared:WaitForChild("SimulatedData"))
local SettingsClient = require(script.Parent:WaitForChild("SettingsClient"))
local Navigation = require(script.Parent:WaitForChild("Navigation"))
local Input = require(script.Parent:WaitForChild("Input"))
local Guide = require(script.Parent:WaitForChild("Guide"))
local HomeScreen = require(script.Parent:WaitForChild("HomeScreen"))
local SectionScreen = require(script.Parent:WaitForChild("SectionScreen"))
local DetailScreen = require(script.Parent:WaitForChild("DetailScreen"))

local Dashboard = {}
Dashboard.__index = Dashboard

export type Dashboard = typeof(setmetatable({}, Dashboard))

function Dashboard.new(playerGui: GuiObject): Dashboard
	local self = setmetatable({}, Dashboard)

	local screenGui = Instance.new("ScreenGui")
	screenGui.Name = "RoBoxGui"
	screenGui.ResetOnSpawn = false
	screenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	screenGui.Parent = playerGui

	local container = Instance.new("Frame")
	container.Name = "Container"
	container.Size = UDim2.new(1, 0, 1, 0)
	container.BackgroundColor3 = Theme.Colors.Background
	container.BorderSizePixel = 0
	container.Parent = screenGui

	local content = Instance.new("Frame")
	content.Name = "Content"
	content.Size = UDim2.new(1, 0, 1, 0)
	content.BackgroundTransparency = 1
	content.BorderSizePixel = 0
	content.Parent = container

	self._screenGui = screenGui
	self._container = container
	self._content = content

	self._nav = Navigation.new()
	self._input = Input.new()
	self._guide = Guide.new(screenGui)
	self._settings = SettingsClient.new()

	self._stack: { any } = {}
	self._home: any = nil

	return self
end

function Dashboard:GetContainer(): GuiObject
	return self._content
end

function Dashboard:GetSettings()
	return self._settings
end

function Dashboard:Boot()
	local nav = self._nav

	-- Sections: Home is the dashboard's own pseudo-section; the other four
	-- are the real destinations.
	nav:RegisterSection("Home", 4)
	for _, sectionId in ipairs(Constants.SECTION_ORDER) do
		nav:RegisterSection(sectionId, 0)
	end

	-- Responsive column count derived from the container width. Read once at
	-- boot; the tile grids wrap automatically within whatever space exists.
	local size = self._container.AbsoluteSize
	local width = size.X > 0 and size.X or 1200
	local columns = math.clamp(math.floor(width / 300), 1, 6)
	nav:SetColumns(columns)

	self._home = HomeScreen.new(self, nav, self._settings)
	table.insert(self._stack, self._home)

	-- Selection highlight follows the navigation controller for every screen.
	nav.SelectionChanged:Connect(function(sectionId: string, index: number)
		local screen = self._stack[#self._stack]
		if screen and screen.OnSelectionChanged then
			screen:OnSelectionChanged(sectionId, index)
		end
	end)

	-- Tile activation flows through the tile's own callback, set by the
	-- screen that owns it (mouse click and keyboard/gamepad share one path).
	nav.TileActivated:Connect(function(_sectionId: string, _index: number, tile: any?)
		if tile then
			tile:Activate()
		end
	end)

	nav.GuideToggled:Connect(function(isOpen: boolean)
		if isOpen then
			self._guide:Open(self:_guideItems())
		else
			self._guide:Close()
		end
	end)

	self._home:Show()
	nav:SelectSection("Home")

	self._input:Connect({
		OnNavigate = function(direction: string)
			if self._guide:IsOpen() then
				if direction == "Up" or direction == "Left" then
					self._guide:SelectPrevious()
				else
					self._guide:SelectNext()
				end
			else
				nav:Move(direction)
			end
		end,
		OnActivate = function()
			if self._guide:IsOpen() then
				self._guide:ActivateSelected()
			else
				nav:ActivateSelected()
			end
		end,
		OnBack = function()
			if self._guide:IsOpen() then
				nav:CloseGuide(true)
			else
				self:PopScreen()
			end
		end,
		OnToggleGuide = function()
			nav:ToggleGuide()
		end,
	})

	print("[RoBox Dashboard] client loaded")
end

-- Guide menu items. Selecting a section closes the guide (restoring the
-- previous selection) and opens that section's screen.
function Dashboard:_guideItems(): { { Text: string, OnActivated: () -> any } }
	local items = {
		{
			Text = "Resume",
			OnActivated = function()
				self._nav:CloseGuide(true)
			end,
		},
	}
	for _, section in ipairs(SimulatedData.GetSections()) do
		table.insert(items, {
			Text = section.Title,
			OnActivated = function()
				self:OpenSection(section)
			end,
		})
	end
	return items
end

function Dashboard:OpenSection(section: { Id: string, Title: string })
	self._nav:CloseGuide(true)
	local current = self._stack[#self._stack]
	if
		current ~= self._home
		and current._section
		and current._section.Id == section.Id
	then
		return
	end
	local screen = SectionScreen.new(self, self._nav, section)
	self:PushScreen(screen)
end

function Dashboard:PushScreen(screen: any)
	local current = self._stack[#self._stack]
	if current == screen then
		return
	end
	if current then
		current:Hide()
	end
	table.insert(self._stack, screen)
	screen:Show()

	if screen == self._home then
		self._nav:SelectSection("Home")
	elseif screen._section then
		self._nav:SelectSection(screen._section.Id)
	end
end

function Dashboard:PopScreen()
	if #self._stack <= 1 then
		return
	end
	if self._guide:IsOpen() then
		self._nav:CloseGuide(true)
	end
	local current = table.remove(self._stack)
	current:Hide()
	local previous = self._stack[#self._stack]
	previous:Show()
	if previous == self._home then
		self._nav:SelectSection("Home")
	end
end

return Dashboard
