--!strict
--[[
init.lua
RoBox dashboard client entry point.

Rojo maps this file (init.lua) to a LocalScript under
StarterPlayer.StarterPlayerScripts, so it runs once per local player.
]]

local Players = game:GetService("Players")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local Dashboard = require(script.Parent:WaitForChild("Dashboard"))

local dashboard = Dashboard.new(playerGui)
dashboard:Boot()
