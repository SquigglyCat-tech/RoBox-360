--!strict
--[[
DetailScreen.lua
Stub detail screen for a dashboard tile.

Milestone 1 does not implement system apps (launching games, opening the
store, etc.). This screen honestly reports that instead of presenting a
placeholder button that pretends to work. It has real behavior: it shows a
message and a Back tile that returns to the previous screen.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RoBox = ReplicatedStorage:WaitForChild("RoBox")
local Shared = RoBox:WaitForChild("Shared")

local Theme = require(Shared:WaitForChild("Theme"))
local Tile = require(script.Parent:WaitForChild("Tile"))

local DetailScreen = {}
DetailScreen.__index = DetailScreen

export type DetailScreen = typeof(setmetatable({}, DetailScreen))

function DetailScreen.new(dashboard, nav, tileData): DetailScreen
	local self = setmetatable({}, DetailScreen)
	self._dashboard = dashboard
	self._nav = nav
	self._tileData = tileData
	self._frame: Frame? = nil
	self._backTile: Tile? = nil
	return self
end

function DetailScreen:Show()
	if self._frame then
		self._frame.Visible = true
		return
	end
	self:_build()
end

function DetailScreen:Hide()
	if self._frame then
		self._frame.Visible = false
	end
end

function DetailScreen:_build()
	local content = self._dashboard:GetContainer()
	local data = self._tileData

	local frame = Instance.new("Frame")
	frame.Name = "Detail_" .. (data.Id or "screen")
	frame.Size = UDim2.new(1, 0, 1, 0)
	frame.BackgroundTransparency = 1
	frame.BorderSizePixel = 0
	frame.Parent = content

	local back = Tile.new(frame, {
		Id = "detail-back",
		Title = "Back",
		Subtitle = "Return to previous screen",
		Glyph = "←",
		Position = UDim2.new(0, Theme.Spacing.Large, 0, Theme.Spacing.Large),
		Size = UDim2.new(0, 220, 0, 90),
		OnActivated = function()
			self._dashboard:PopScreen()
		end,
	})
	self._backTile = back

	local title = Instance.new("TextLabel")
	title.Name = "Title"
	title.Size = UDim2.new(0, 500, 0, 44)
	title.Position = UDim2.new(0, Theme.Spacing.Large + 240, 0, Theme.Spacing.Large + 10)
	title.BackgroundTransparency = 1
	title.Text = data.Title or "Item"
	title.TextColor3 = Theme.Colors.Text
	title.TextSize = 32
	title.Font = Theme.Font("Display", Enum.FontWeight.SemiBold)
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.Parent = frame

	local body = Instance.new("TextLabel")
	body.Name = "Body"
	body.Size = UDim2.new(0, 600, 0, 200)
	body.Position = UDim2.new(0, Theme.Spacing.Large + 240, 0, Theme.Spacing.Large + 70)
	body.BackgroundTransparency = 1
	body.Text = "This system app is not part of milestone 1.\n\nIt will be implemented in a later milestone as original RoBox functionality."
	body.TextColor3 = Theme.Colors.TextMuted
	body.TextSize = 18
	body.Font = Theme.Font("Body", Enum.FontWeight.Regular)
	body.TextXAlignment = Enum.TextXAlignment.Left
	body.TextWrapped = true
	body.Parent = frame

	local note = Instance.new("TextLabel")
	note.Name = "Note"
	note.Size = UDim2.new(0, 600, 0, 20)
	note.Position = UDim2.new(0, Theme.Spacing.Large + 240, 0, Theme.Spacing.Large + 70 + 200 + 10)
	note.BackgroundTransparency = 1
	note.Text = "All data shown here is simulated."
	note.TextColor3 = Theme.Colors.TextDim
	note.TextSize = 13
	note.Font = Theme.Font("Body", Enum.FontWeight.Regular)
	note.TextXAlignment = Enum.TextXAlignment.Left
	note.Parent = frame

	self._frame = frame
end

function DetailScreen:Destroy()
	if self._backTile then
		self._backTile:Destroy()
		self._backTile = nil
	end
	if self._frame then
		self._frame:Destroy()
		self._frame = nil
	end
end

return DetailScreen
