--!strict
--[[
SectionScreen.lua
Generic shell screen for a dashboard section (Games, Apps, Settings, Profile).

Milestone 1 scope: navigation target with a back tile and the section's
simulated tiles. Real system apps are intentionally not implemented; activating
a tile opens a DetailScreen stub, except Settings > Audio, which opens a live
volume pane that persists through SettingsClient (server-validated).
]]

local TweenService = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RoBox = ReplicatedStorage:WaitForChild("RoBox")
local Shared = RoBox:WaitForChild("Shared")

local Theme = require(Shared:WaitForChild("Theme"))
local SimulatedData = require(Shared:WaitForChild("SimulatedData"))
local SettingsSchema = require(Shared:WaitForChild("SettingsSchema"))
local Tile = require(script.Parent:WaitForChild("Tile"))
local DetailScreen = require(script.Parent:WaitForChild("DetailScreen"))

local SectionScreen = {}
SectionScreen.__index = SectionScreen

export type SectionScreen = typeof(setmetatable({}, SectionScreen))

function SectionScreen.new(dashboard, nav, section): SectionScreen
	local self = setmetatable({}, SectionScreen)
	self._dashboard = dashboard
	self._nav = nav
	self._section = section
	self._frame: Frame? = nil
	self._tiles: { Tile } = {}
	self._pane: Frame? = nil -- inline audio settings pane
	return self
end

function SectionScreen:Show()
	if self._frame then
		self._frame.Visible = true
		self:_refreshSelection()
		return
	end
	self:_build()
	self:_refreshSelection()
end

function SectionScreen:Hide()
	if self._frame then
		self._frame.Visible = false
	end
	if self._pane then
		self._pane.Visible = false
	end
end

function SectionScreen:_build()
	local content = self._dashboard:GetContainer()
	local section = self._section

	local frame = Instance.new("Frame")
	frame.Name = "Section_" .. section.Id
	frame.Size = UDim2.new(1, 0, 1, 0)
	frame.BackgroundTransparency = 1
	frame.BorderSizePixel = 0
	frame.Parent = content

	local back = Tile.new(frame, {
		Id = "section-back",
		Title = "Back",
		Subtitle = "Return to home",
		Glyph = "←",
		Section = section.Id,
		Position = UDim2.new(0, Theme.Spacing.Large, 0, Theme.Spacing.Large),
		Size = UDim2.new(0, 220, 0, 90),
		OnActivated = function()
			self._dashboard:PopScreen()
		end,
	})
	table.insert(self._tiles, back)

	local title = Instance.new("TextLabel")
	title.Name = "Title"
	title.Size = UDim2.new(0, 400, 0, 40)
	title.Position = UDim2.new(0, Theme.Spacing.Large + 240, 0, Theme.Spacing.Large + 10)
	title.BackgroundTransparency = 1
	title.Text = section.Title
	title.TextColor3 = Theme.Colors.Text
	title.TextSize = 32
	title.Font = Theme.Font("Display", Enum.FontWeight.SemiBold)
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.Parent = frame

	local subtitle = Instance.new("TextLabel")
	subtitle.Name = "Subtitle"
	subtitle.Size = UDim2.new(0, 400, 0, 20)
	subtitle.Position = UDim2.new(0, Theme.Spacing.Large + 240, 0, Theme.Spacing.Large + 52)
	subtitle.BackgroundTransparency = 1
	subtitle.Text = section.Subtitle .. "  ·  " .. tostring(#SimulatedData.GetTiles(section.Id)) .. " items (simulated)"
	subtitle.TextColor3 = Theme.Colors.TextMuted
	subtitle.TextSize = 14
	subtitle.Font = Theme.Font("Body", Enum.FontWeight.Regular)
	subtitle.TextXAlignment = Enum.TextXAlignment.Left
	subtitle.Parent = frame

	local grid = Instance.new("Frame")
	grid.Name = "Grid"
	grid.Size = UDim2.new(1, -Theme.Spacing.Large * 2, 1, -Theme.Spacing.XLarge - 40)
	grid.Position = UDim2.new(0, Theme.Spacing.Large, 0, Theme.Spacing.XLarge + 50)
	grid.BackgroundTransparency = 1
	grid.Parent = frame

	local layout = Instance.new("UIGridLayout")
	layout.Name = "Layout"
	layout.CellSize = Theme.Tile.Size
	layout.CellPadding = UDim.new(0, Theme.Spacing.Medium)
	layout.HorizontalAlignment = Enum.HorizontalAlignment.Left
	layout.VerticalAlignment = Enum.VerticalAlignment.Top
	layout.SortOrder = Enum.SortOrder.LayoutOrder
	layout.Parent = grid

	local tiles = SimulatedData.GetTiles(section.Id)
	for i, data in ipairs(tiles) do
		local tileIndex = i
		local tile = Tile.new(grid, {
			Id = data.Id,
			Title = data.Title,
			Subtitle = data.Subtitle,
			Glyph = data.Glyph,
			Section = section.Id,
			Data = data,
			LayoutOrder = i,
			OnActivated = function(t)
				self:_onTileActivated(t, data)
			end,
			OnHovered = function(t)
				self._nav:SelectIndex(self._section.Id, tileIndex)
			end,
		})
		table.insert(self._tiles, tile)
	end

	self._frame = frame
	self._grid = grid
	self._sectionTiles = tiles
end

function SectionScreen:_onTileActivated(tile: Tile, data: any)
	if self._pane and self._pane.Visible then
		return
	end
	if data.Section == "Settings" and data.Id == "set-audio" then
		self:_openAudioPane()
		return
	end
	self._dashboard:PushScreen(DetailScreen.new(self._dashboard, self._nav, data))
end

function SectionScreen:OnSelectionChanged(sectionId: string, index: number)
	if sectionId ~= self._section.Id then
		return
	end
	for i, tile in ipairs(self._tiles) do
		if i == index then
			tile:Select()
		else
			tile:Deselect()
		end
	end
end

function SectionScreen:_refreshSelection()
	local index = self._nav:GetSelectedIndex(self._section.Id)
	for i, tile in ipairs(self._tiles) do
		if i == index then
			tile:Select()
		else
			tile:Deselect()
		end
	end
end

-- Inline audio settings pane: demonstrates functional Settings with
-- server-validated persistence (Volume).
function SectionScreen:_openAudioPane()
	local content = self._dashboard:GetContainer()
	local pane = Instance.new("Frame")
	pane.Name = "AudioPane"
	pane.Size = UDim2.new(0, 420, 0, 250)
	pane.Position = UDim2.new(0.5, -210, 0.5, -125)
	pane.BackgroundColor3 = Theme.Colors.PanelElevated
	pane.BorderSizePixel = 0
	pane.ZIndex = 30
	pane.Parent = content

	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 16)
	corner.Parent = pane

	local title = Instance.new("TextLabel")
	title.Size = UDim2.new(1, -32, 0, 32)
	title.Position = UDim2.new(0, 20, 0, 18)
	title.BackgroundTransparency = 1
	title.Text = "Audio"
	title.TextColor3 = Theme.Colors.Text
	title.TextSize = 24
	title.Font = Theme.Font("Display", Enum.FontWeight.SemiBold)
	title.TextXAlignment = Enum.TextXAlignment.Left
	title.ZIndex = 31
	title.Parent = pane

	local note = Instance.new("TextLabel")
	note.Size = UDim2.new(1, -40, 0, 20)
	note.Position = UDim2.new(0, 20, 0, 52)
	note.BackgroundTransparency = 1
	note.Text = "Volume (persisted on server)"
	note.TextColor3 = Theme.Colors.TextMuted
	note.TextSize = 14
	note.Font = Theme.Font("Body", Enum.FontWeight.Regular)
	note.TextXAlignment = Enum.TextXAlignment.Left
	note.ZIndex = 31
	note.Parent = pane

	local value = Instance.new("TextLabel")
	value.Name = "Value"
	value.Size = UDim2.new(0, 80, 0, 28)
	value.Position = UDim2.new(0, 20, 0, 86)
	value.BackgroundTransparency = 1
	value.Text = string.format("%.0f%%", self._dashboard:GetSettings():Get("Volume") * 100)
	value.TextColor3 = Theme.Colors.Text
	value.TextSize = 20
	value.Font = Theme.Font("Body", Enum.FontWeight.SemiBold)
	value.TextXAlignment = Enum.TextXAlignment.Left
	value.ZIndex = 31
	value.Parent = pane

	local function setVolume(volume: number)
		local ok = self._dashboard:GetSettings():Set("Volume", volume)
		if ok then
			local current = self._dashboard:GetSettings():Get("Volume")
			value.Text = string.format("%.0f%%", current * 100)
			self:_updateAudioTileSubtitle(current)
			self:_showToast("Volume saved")
		else
			self:_showToast("Save failed -- kept locally")
		end
	end

	local function makeButton(text: string, position: UDim2, delta: number?)
		local button = Instance.new("TextButton")
		button.Size = UDim2.new(0, 110, 0, 40)
		button.Position = position
		button.BackgroundColor3 = Theme.Colors.Panel
		button.BorderSizePixel = 0
		button.Text = text
		button.TextColor3 = Theme.Colors.Text
		button.TextSize = 18
		button.Font = Theme.Font("Body", Enum.FontWeight.SemiBold)
		button.ZIndex = 31
		button.Parent = pane
		local c = Instance.new("UICorner")
		c.CornerRadius = UDim.new(0, 8)
		c.Parent = button
		button.MouseButton1Click:Connect(function()
			if delta then
				setVolume(math.clamp((self._dashboard:GetSettings():Get("Volume") or 0.7) + delta, 0, 1))
			end
		end)
		return button
	end

	makeButton("-", UDim2.new(0, 20, 0, 130), -0.1)
	makeButton("+", UDim2.new(0, 140, 0, 130), 0.1)

	local done = Instance.new("TextButton")
	done.Name = "Done"
	done.Size = UDim2.new(0, 110, 0, 40)
	done.Position = UDim2.new(0, 260, 0, 130)
	done.BackgroundColor3 = Theme.Colors.Accent
	done.BorderSizePixel = 0
	done.Text = "Done"
	done.TextColor3 = Color3.new(0, 0, 0)
	done.TextSize = 18
	done.Font = Theme.Font("Body", Enum.FontWeight.SemiBold)
	done.ZIndex = 31
	done.Parent = pane
	local cd = Instance.new("UICorner")
	cd.CornerRadius = UDim.new(0, 8)
	cd.Parent = done

	done.MouseButton1Click:Connect(function()
		self:_closeAudioPane()
	end)

	self._pane = pane
end

function SectionScreen:_closeAudioPane()
	if self._pane then
		self._pane:Destroy()
		self._pane = nil
	end
end

function SectionScreen:_updateAudioTileSubtitle(volume: number)
	local text = string.format("Volume and output  ·  %.0f%%", volume * 100)
	for i, tile in ipairs(self._tiles) do
		if tile.Id == "set-audio" then
			tile:SetSubtitle(text)
			break
		end
	end
end

function SectionScreen:_showToast(message: string)
	local content = self._dashboard:GetContainer()
	local toast = Instance.new("TextLabel")
	toast.Name = "Toast"
	toast.Size = UDim2.new(0, 260, 0, 30)
	toast.Position = UDim2.new(0.5, -130, 1, -Theme.Spacing.Large)
	toast.BackgroundColor3 = Theme.Colors.PanelElevated
	toast.BorderSizePixel = 0
	toast.Text = message
	toast.TextColor3 = Theme.Colors.Text
	toast.TextSize = 14
	toast.Font = Theme.Font("Body", Enum.FontWeight.Regular)
	toast.ZIndex = 40
	toast.Parent = content
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 8)
	corner.Parent = toast
	local stroke = Instance.new("UIStroke")
	stroke.Color = Theme.Colors.Border
	stroke.Thickness = 1
	stroke.Parent = toast

	TweenService:Create(toast, Theme.Animation.Toast, { TextTransparency = 1, BackgroundTransparency = 1 }):Play()
	task.delay(2.0, function()
		toast:Destroy()
	end)
end

function SectionScreen:Destroy()
	for _, tile in ipairs(self._tiles) do
		tile:Destroy()
	end
	self._tiles = {}
	if self._pane then
		self._pane:Destroy()
		self._pane = nil
	end
	if self._frame then
		self._frame:Destroy()
		self._frame = nil
	end
end

return SectionScreen
