--!strict
--[[
HomeScreen.lua
RoBox home screen: the dashboard shell's entry point.

Shows one tile per section (Games, Apps, Settings, Profile) plus a wordmark.
Selecting a section tile opens that section's screen. This is the only screen
shown when the dashboard boots.
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RoBox = ReplicatedStorage:WaitForChild("RoBox")
local Shared = RoBox:WaitForChild("Shared")

local Theme = require(Shared:WaitForChild("Theme"))
local Constants = require(Shared:WaitForChild("Constants"))
local SimulatedData = require(Shared:WaitForChild("SimulatedData"))
local Tile = require(script.Parent:WaitForChild("Tile"))

local HomeScreen = {}
HomeScreen.__index = HomeScreen

export type HomeScreen = typeof(setmetatable({}, HomeScreen))

function HomeScreen.new(dashboard, nav, settings): HomeScreen
	local self = setmetatable({}, HomeScreen)
	self._dashboard = dashboard
	self._nav = nav
	self._settings = settings
	self._frame: Frame? = nil
	self._tiles: { Tile } = {}
	self._sectionByTile: { [Tile]: { Id: string } } = {}
	return self
end

function HomeScreen:Show()
	if self._frame then
		self._frame.Visible = true
		self:_refreshSelection()
		return
	end
	self:_build()
	-- Register the home tiles with the navigation controller so keyboard,
	-- gamepad and mouse-hover selection stay unified with the highlight.
	self._nav:SetTiles("Home", self._tiles)
	self:_refreshSelection()
end

function HomeScreen:Hide()
	if self._frame then
		self._frame.Visible = false
	end
end

function HomeScreen:_build()
	local content = self._dashboard:GetContainer()

	local frame = Instance.new("Frame")
	frame.Name = "HomeScreen"
	frame.Size = UDim2.new(1, 0, 1, 0)
	frame.BackgroundTransparency = 1
	frame.BorderSizePixel = 0
	frame.Parent = content

	local wordmark = Instance.new("TextLabel")
	wordmark.Name = "Wordmark"
	wordmark.Size = UDim2.new(0, 300, 0, 56)
	wordmark.Position = UDim2.new(0, Theme.Spacing.Large, 0, Theme.Spacing.Large)
	wordmark.BackgroundTransparency = 1
	wordmark.Text = "RoBox"
	wordmark.TextColor3 = Theme.Colors.Text
	wordmark.TextSize = 40
	wordmark.Font = Theme.Font("Display", Enum.FontWeight.Bold)
	wordmark.TextXAlignment = Enum.TextXAlignment.Left
	wordmark.Parent = frame

	local tagline = Instance.new("TextLabel")
	tagline.Name = "Tagline"
	tagline.Size = UDim2.new(0, 500, 0, 20)
	tagline.Position = UDim2.new(0, Theme.Spacing.Large, 0, Theme.Spacing.Large + 52)
	tagline.BackgroundTransparency = 1
	tagline.Text = "Unofficial Metro-style dashboard  ·  simulated data"
	tagline.TextColor3 = Theme.Colors.TextDim
	tagline.TextSize = 14
	tagline.Font = Theme.Font("Body", Enum.FontWeight.Regular)
	tagline.TextXAlignment = Enum.TextXAlignment.Left
	tagline.Parent = frame

	local grid = Instance.new("Frame")
	grid.Name = "Grid"
	grid.Size = UDim2.new(1, -Theme.Spacing.Large * 2, 1, -Theme.Spacing.XLarge * 2)
	grid.Position = UDim2.new(0, Theme.Spacing.Large, 0, Theme.Spacing.XLarge)
	grid.BackgroundTransparency = 1
	grid.Parent = frame

	local layout = Instance.new("UIGridLayout")
	layout.Name = "Layout"
	layout.CellSize = Theme.Tile.Size
	layout.CellPadding = UDim.new(0, Theme.Spacing.Medium)
	layout.HorizontalAlignment = Enum.HorizontalAlignment.Left
	layout.VerticalAlignment = Enum.VerticalAlignment.Top
	layout.SortOrder = Enum.SortOrder.LayoutOrder
	layout.Parent = grid

	local sections = SimulatedData.GetSections()
	for i, section in ipairs(sections) do
		local tileIndex = i
		local tile = Tile.new(grid, {
			Id = "home-section-" .. section.Id,
			Title = section.Title,
			Subtitle = section.Subtitle,
			Glyph = section.Glyph,
			Section = section.Id,
			Data = section,
			LayoutOrder = i,
			OnActivated = function(t)
				self:_onSectionActivated(t)
			end,
			OnHovered = function(t)
				self._nav:SelectIndex("Home", tileIndex)
			end,
		})
		table.insert(self._tiles, tile)
		self._sectionByTile[tile] = section
	end

	local hint = Instance.new("TextLabel")
	hint.Name = "Hint"
	hint.Size = UDim2.new(1, 0, 0, 20)
	hint.Position = UDim2.new(0, Theme.Spacing.Large, 1, -Theme.Spacing.Medium)
	hint.AnchorPoint = Vector2.new(0, 1)
	hint.BackgroundTransparency = 1
	hint.Text = "Arrows / DPad move  ·  Enter / A open  ·  G / Start Guide  ·  Esc / B back"
	hint.TextColor3 = Theme.Colors.TextDim
	hint.TextSize = 13
	hint.Font = Theme.Font("Body", Enum.FontWeight.Regular)
	hint.TextXAlignment = Enum.TextXAlignment.Left
	hint.Parent = frame

	self._frame = frame
end

function HomeScreen:_onSectionActivated(tile: Tile)
	local section = self._sectionByTile[tile]
	if not section then
		return
	end
	self._dashboard:OpenSection(section)
end

function HomeScreen:OnSelectionChanged(sectionId: string, index: number)
	if sectionId ~= "Home" then
		return
	end
	for i, tile in ipairs(self._tiles) do
		if i == index then
			tile:Select()
		else
			tile:Deselect()
		end
	end
end

function HomeScreen:_refreshSelection()
	local sectionId = self._nav.CurrentSection
	if sectionId ~= "Home" then
		return
	end
	local index = self._nav:GetSelectedIndex("Home")
	for i, tile in ipairs(self._tiles) do
		if i == index then
			tile:Select()
		else
			tile:Deselect()
		end
	end
end

function HomeScreen:Destroy()
	for _, tile in ipairs(self._tiles) do
		tile:Destroy()
	end
	self._tiles = {}
	if self._frame then
		self._frame:Destroy()
		self._frame = nil
	end
end

return HomeScreen
