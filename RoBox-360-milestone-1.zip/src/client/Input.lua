--!strict
--[[
Input.lua
Maps raw input (keyboard, gamepad) to logical navigation actions.

Mouse interaction is handled directly by tiles (hover/click), so this module
only needs keyboard and gamepad. A held thumbstick fires once per
GamepadRepeatInterval and only when the direction changes -- no polling, no
unbounded loops.
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RoBox = ReplicatedStorage:WaitForChild("RoBox")
local Shared = RoBox:WaitForChild("Shared")

local Constants = require(Shared:WaitForChild("Constants"))

local Input = {}
Input.__index = Input

export type Input = typeof(setmetatable({}, Input))
export type Callbacks = {
	OnNavigate: ((direction: string) -> any)?,
	OnActivate: (() -> any)?,
	OnBack: (() -> any)?,
	OnToggleGuide: (() -> any)?,
}

local function contains(list: { any }, value: any): boolean
	for _, v in ipairs(list) do
		if v == value then
			return true
		end
	end
	return false
end

function Input.new(): Input
	local self = setmetatable({}, Input)
	self._onNavigate: (string -> any)? = nil
	self._onActivate: (() -> any)? = nil
	self._onBack: (() -> any)? = nil
	self._onToggleGuide: (() -> any)? = nil
	self._connections: { RBXScriptConnection } = {}
	self._stickDirection: string? = nil
	self._stickLastFire = 0
	self._connected = false
	return self
end

function Input:Connect(callbacks: Callbacks)
	self._onNavigate = callbacks.OnNavigate
	self._onActivate = callbacks.OnActivate
	self._onBack = callbacks.OnBack
	self._onToggleGuide = callbacks.OnToggleGuide

	self._connections = {
		UserInputService.InputBegan:Connect(function(input: InputObject, processed: boolean)
			if processed then
				return
			end
			self:OnInputBegan(input)
		end),
		UserInputService.InputChanged:Connect(function(input: InputObject, processed: boolean)
			if processed then
				return
			end
			if input.UserInputType == Enum.UserInputType.Gamepad1 then
				self:OnGamepadStick(input)
			end
		end),
		UserInputService.InputEnded:Connect(function(input: InputObject, processed: boolean)
			if processed then
				return
			end
			if
				input.UserInputType == Enum.UserInputType.Gamepad1
				and input.KeyCode == Constants.Input.Gamepad.Thumbstick
			then
				self._stickDirection = nil
			end
		end),
	}
	self._connected = true
end

function Input:Disconnect()
	for _, connection in ipairs(self._connections) do
		connection:Disconnect()
	end
	self._connections = {}
	self._connected = false
end

function Input:OnInputBegan(input: InputObject)
	if input.UserInputType == Enum.UserInputType.Keyboard then
		local code = input.KeyCode
		if code == Enum.KeyCode.Up or code == Enum.KeyCode.W then
			self:_navigate("Up")
		elseif code == Enum.KeyCode.Down or code == Enum.KeyCode.S then
			self:_navigate("Down")
		elseif code == Enum.KeyCode.Left or code == Enum.KeyCode.A then
			self:_navigate("Left")
		elseif code == Enum.KeyCode.Right or code == Enum.KeyCode.D then
			self:_navigate("Right")
		elseif contains(Constants.Input.Activate, code) then
			self:_activate()
		elseif contains(Constants.Input.Back, code) then
			self:_back()
		elseif contains(Constants.Input.Guide, code) then
			self:_toggleGuide()
		end
		return
	end

	if input.UserInputType == Enum.UserInputType.Gamepad1 then
		local code = input.KeyCode
		local g = Constants.Input.Gamepad
		if code == g.Activate then
			self:_activate()
		elseif code == g.Back then
			self:_back()
		elseif code == g.Guide then
			self:_toggleGuide()
		elseif code == g.Up then
			self:_navigate("Up")
		elseif code == g.Down then
			self:_navigate("Down")
		elseif code == g.Left or code == g.Previous then
			self:_navigate("Left")
		elseif code == g.Right or code == g.Next then
			self:_navigate("Right")
		end
	end
end

function Input:OnGamepadStick(input: InputObject)
	local deadzone = Constants.GamepadDeadzone
	local x = input.Position.X
	local y = input.Position.Y
	local now = os.clock()
	if now - self._stickLastFire < Constants.GamepadRepeatInterval then
		return
	end

	local direction: string? = nil
	if math.abs(x) > deadzone and math.abs(x) > math.abs(y) then
		direction = x > 0 and "Right" or "Left"
	elseif math.abs(y) > deadzone then
		direction = y > 0 and "Down" or "Up"
	end

	if direction then
		if self._stickDirection ~= direction then
			self._stickDirection = direction
			self._stickLastFire = now
			self:_navigate(direction)
		end
	else
		self._stickDirection = nil
	end
end

function Input:_navigate(direction: string)
	if self._onNavigate then
		self._onNavigate(direction)
	end
end

function Input:_activate()
	if self._onActivate then
		self._onActivate()
	end
end

function Input:_back()
	if self._onBack then
		self._onBack()
	end
end

function Input:_toggleGuide()
	if self._onToggleGuide then
		self._onToggleGuide()
	end
end

return Input
