--!strict
--[[
SimulatedData.shared.lua
SIMULATED SYSTEM DATA -- not real Roblox platform data.

Every entry here is fabricated for the dashboard shell. Nothing is fetched
from Roblox services. The module and its entries are flagged SIMULATED_DATA
so reviewers can tell at a glance which content is placeholder data to be
replaced by real platform APIs in later milestones.
]]

local SimulatedData = {}
SimulatedData.SIMULATED_DATA = true

local function tile(id: string, title: string, subtitle: string, glyph: string, section: string)
	return {
		Id = id,
		Title = title,
		Subtitle = subtitle,
		Glyph = glyph,
		Section = section,
	}
end

local GAMES = {
	tile("game-recent-1", "Adopt Me!", "Recently played 2h ago", "◆", "Games"),
	tile("game-recent-2", "Bloxburg", "Continue your save", "◆", "Games"),
	tile("game-recent-3", "RoBox Speedway", "New update available", "◆", "Games"),
}

local APPS = {
	tile("app-browser", "RoBox Browser", "Web · beta", "◆", "Apps"),
	tile("app-messages", "Messages", "3 unread", "◆", "Apps"),
	tile("app-store", "RoBox Store", "Shop items", "◆", "Apps"),
	tile("app-friends", "Friends", "12 online", "◆", "Apps"),
}

local SETTINGS = {
	tile("set-display", "Display", "Theme and resolution", "⚙", "Settings"),
	tile("set-audio", "Audio", "Volume and output", "⚙", "Settings"),
	tile("set-account", "Account", "Privacy and login", "⚙", "Settings"),
}

local PROFILE = {
	tile("prof-badge", "Player Badge", "View achievements", "★", "Profile"),
	tile("prof-outfit", "Outfits", "Manage avatar gear", "★", "Profile"),
	tile("prof-privacy", "Privacy", "Who can message you", "★", "Profile"),
}

function SimulatedData.GetTiles(section: string): { { Id: string } }
	local bySection = {
		Games = GAMES,
		Apps = APPS,
		Settings = SETTINGS,
		Profile = PROFILE,
	}
	return bySection[section] or {}
end

function SimulatedData.GetSections(): { { Id: string, Title: string, Subtitle: string, Glyph: string, Color: Color3 } }
	return {
		{ Id = "Games", Title = "Games", Subtitle = "Play", Glyph = "◆", Color = Color3.fromHex("#7C5CFC") },
		{ Id = "Apps", Title = "Apps", Subtitle = "Tools", Glyph = "⚙", Color = Color3.fromHex("#22C3AA") },
		{ Id = "Settings", Title = "Settings", Subtitle = "System", Glyph = "⚙", Color = Color3.fromHex("#F5A623") },
		{ Id = "Profile", Title = "Profile", Subtitle = "You", Glyph = "★", Color = Color3.fromHex("#E05CE0") },
	}
end

return SimulatedData
