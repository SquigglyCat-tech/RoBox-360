--!strict
--[[
SettingsSchema.shared.lua
Defaults, schema and validation for persisted RoBox settings.

The same module is required by the client settings cache and the server
persistence service, so both sides validate identically.
]]

local SettingsSchema = {}

SettingsSchema.DEFAULTS = {
	Volume = 0.7,
	Notifications = true,
	Language = "en",
	Rumble = true,
}

local LANGUAGES = { en = true, es = true, fr = true, de = true }

SettingsSchema.SCHEMA = {
	Volume = { Type = "number", Min = 0, Max = 1 },
	Notifications = { Type = "boolean" },
	Language = { Type = "string", Enum = LANGUAGES },
	Rumble = { Type = "boolean" },
}

function SettingsSchema.IsValidKey(key: string): boolean
	return SettingsSchema.SCHEMA[key] ~= nil
end

-- Clamps and type-coerces where safe. Returns (ok, cleanedValue, errorMessage).
function SettingsSchema.Validate(key: string, value: any): (boolean, any, string?)
	local rule = SettingsSchema.SCHEMA[key]
	if not rule then
		return false, nil, "unknown setting key: " .. tostring(key)
	end

	local expected = rule.Type
	if expected == "number" then
		if typeof(value) ~= "number" then
			if typeof(value) == "string" then
				local n = tonumber(value)
				if not n then
					return false, nil, "expected number"
				end
				value = n
			else
				return false, nil, "expected number"
			end
		end
		if rule.Min ~= nil and value < rule.Min then
			value = rule.Min
		end
		if rule.Max ~= nil and value > rule.Max then
			value = rule.Max
		end
		return true, value, nil
	elseif expected == "boolean" then
		if typeof(value) ~= "boolean" then
			return false, nil, "expected boolean"
		end
		return true, value, nil
	elseif expected == "string" then
		if typeof(value) ~= "string" then
			return false, nil, "expected string"
		end
		if rule.Enum and not rule.Enum[value] then
			return false, nil, "value not in enum: " .. value
		end
		return true, value, nil
	end

	return false, nil, "unsupported type: " .. tostring(expected)
end

function SettingsSchema.CloneDefaults(): { [string]: any }
	local clone = {}
	for k, v in pairs(SettingsSchema.DEFAULTS) do
		clone[k] = v
	end
	return clone
end

return SettingsSchema
