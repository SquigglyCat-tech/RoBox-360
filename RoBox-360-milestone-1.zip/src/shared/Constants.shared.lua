--!strict
--[[
Constants.shared.lua
Shared constants for the RoBox dashboard.

Branding note: this is an ORIGINAL RoBox identity. It is not Xbox, it is not
the Xbox OS, and no Microsoft assets are used.
]]

local Constants = {}

Constants.Brand = {
	Name = "RoBox",
	Product = "RoBox Dashboard",
}

-- Home screen sections, in display order.
Constants.SECTION_GAMES = "Games"
Constants.SECTION_APPS = "Apps"
Constants.SECTION_SETTINGS = "Settings"
Constants.SECTION_PROFILE = "Profile"

Constants.SECTION_ORDER = {
	Constants.SECTION_GAMES,
	Constants.SECTION_APPS,
	Constants.SECTION_SETTINGS,
	Constants.SECTION_PROFILE,
}

-- Remote used for client <-> server settings persistence.
Constants.REMOTE_NAME = "RoBoxSettings"

-- Logical input mappings. Several physical inputs map to one action so the
-- dashboard works with mouse, keyboard and gamepad without duplicating logic.
Constants.Input = {
	Activate = { Enum.KeyCode.Return, Enum.KeyCode.Space },
	Back = { Enum.KeyCode.Escape },
	Guide = { Enum.KeyCode.G },
	Previous = { Enum.KeyCode.Up, Enum.KeyCode.W, Enum.KeyCode.Left, Enum.KeyCode.A },
	Next = { Enum.KeyCode.Down, Enum.KeyCode.S, Enum.KeyCode.Right, Enum.KeyCode.D },
	Gamepad = {
		Activate = Enum.KeyCode.ButtonA,
		Back = Enum.KeyCode.ButtonB,
		Guide = Enum.KeyCode.ButtonStart,
		Previous = Enum.KeyCode.DPadLeft,
		Next = Enum.KeyCode.DPadRight,
		Up = Enum.KeyCode.DPadUp,
		Down = Enum.KeyCode.DPadDown,
		Thumbstick = Enum.KeyCode.Thumbstick1,
	},
}

-- Gamepad thumbstick deadzone (0..1). Stops drift from triggering navigation.
Constants.GamepadDeadzone = 0.25

-- Minimum seconds between two directional navigations from a held stick.
Constants.GamepadRepeatInterval = 0.18

-- Marker so simulated data is never mistaken for live Roblox platform data.
Constants.SIMULATED_DATA = true

return Constants
