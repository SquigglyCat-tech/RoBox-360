--!strict
--[[
Theme.shared.lua
Reusable theme configuration for the RoBox dashboard.

Fonts: Selawik is the Metro-style face (the Segoe substitute requested for
this project). Selawik is not bundled with Roblox, so it must be uploaded as
a custom font asset and FONT_ASSET_ID replaced below. Until then every
Selawik reference falls back to Gotham so the dashboard still works. See
docs/ASSETS.md for sources and licenses.

The palette is an original RoBox brand palette -- not the Xbox green.
]]

local Theme = {}

Theme.Colors = {
	Background = Color3.fromHex("#0E0E12"),
	Panel = Color3.fromHex("#191920"),
	PanelElevated = Color3.fromHex("#21212B"),
	Accent = Color3.fromHex("#7C5CFC"),     -- RoBox violet
	AccentDim = Color3.fromHex("#5B21B6"),
	AccentGlow = Color3.fromHex("#9F86FF"),
	Text = Color3.fromHex("#FFFFFF"),
	TextMuted = Color3.fromHex("#A9A9B5"),
	TextDim = Color3.fromHex("#6E6E78"),
	Border = Color3.fromHex("#3A3A46"),
	BorderSelected = Color3.fromHex("#7C5CFC"),
	Danger = Color3.fromHex("#E45858"),
	Success = Color3.fromHex("#4CAF50"),
}

Theme.Fonts = {
	Display = "Selawik",   -- large wordmarks and screen titles
	Body = "Selawik",      -- tile titles and labels
	Mono = "Selawik",      -- small metadata
}

-- Replace with the uploaded Selawik font asset id (rbxassetid://...).
-- 0 means "use the family name only", which relies on the font being
-- uploaded to the experience under the name "Selawik".
Theme.FontAssetId = 0

Theme.FontFamilies = {
	Selawik = "Selawik",
	Fallback = "Gotham",
}

Theme.Spacing = {
	XSmall = 4,
	Small = 8,
	Medium = 16,
	Large = 24,
	XLarge = 32,
}

-- Tile geometry in offset pixels. Grids wrap responsively inside the
-- container; the number of visible columns depends on screen size.
Theme.Tile = {
	Size = UDim2.new(0, 286, 0, 160),
	CornerRadius = UDim.new(0, 14),
	BorderThickness = 2,
	SelectedBorderThickness = 3,
	IconSize = 48,
}

-- Restrained animations: one tween per transition, never a loop.
Theme.Animation = {
	Select = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
	Guide = TweenInfo.new(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
	Fade = TweenInfo.new(0.18, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
	Toast = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
}

-- Returns a Font object, preferring the requested family and falling back
-- to Gotham if the custom font is not available in the experience.
function Theme.Font(familyKey: string?, weight: Enum.FontWeight?, style: Enum.FontStyle?): Font
	weight = weight or Enum.FontWeight.Regular
	style = style or Enum.FontStyle.Normal
	local family = (familyKey and Theme.FontFamilies[familyKey]) or Theme.FontFamilies.Body
	return Font.new(family, weight, style)
end

return Theme
