# RoBox Dashboard — Asset Sources and Licenses

RoBox is an ORIGINAL, unofficial Metro-style dashboard for Roblox. It is not
Xbox, not the Xbox OS, and no Microsoft assets, code, or trademarks are used.

## Branding

- **Name:** "RoBox" — original brand name coined for this project.
- **Wordmark:** rendered as text at runtime using the Selawik font face. No
  image asset is required; nothing is copied from Xbox wordmarks or logos.
- **Palette:** original RoBox palette (see `src/shared/Theme.shared.lua`);
  not the Xbox green.

## Fonts

- **Selawik:** requested as the Segoe substitute for the Metro look. Selawik
  is not bundled with Roblox. It must be uploaded to the experience as a
  custom font asset and `Theme.FontAssetId` in
  `src/shared/Theme.shared.lua` updated to its `rbxassetid://...` id, or the
  font must be available in the experience under the family name "Selawik".
- **Fallback:** Gotham (bundled with Roblox) is used automatically when
  Selawik is unavailable, so the dashboard works without any custom font.

Selawik licensing is the responsibility of the person uploading it: confirm
the font's license (e.g. SIL Open Font License or similar) before
distributing the experience. Until a license is confirmed, Gotham fallback
means no unlicensed font is shipped by default.

## Icons

Tile icons are plain Unicode geometric glyphs (◆, ⚙, ★, ←) rendered in
TextLabels. No external image or font icon assets are used.

## Simulated data

`src/shared/SimulatedData.shared.lua` contains fabricated system data
(games, apps, settings, profile). It is flagged `SIMULATED_DATA = true` on
the module and is not connected to any Roblox platform API. Replace it with
real platform integrations in later milestones.

## Third-party tooling

- Rojo (rojo-rbx/rojo, MIT License) — used only as a development build/sync
  tool; not shipped in the experience.
- No runtime dependencies are loaded from the internet.
